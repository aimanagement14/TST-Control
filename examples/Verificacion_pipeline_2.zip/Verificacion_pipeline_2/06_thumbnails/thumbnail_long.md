# Miniatura — guion long (16:9 (horizontal))

_Actualizado: 2026-09-02T16:52:36_

```
A half-buried trilobite fossil in red sandstone, lit by a single volumetric sunbeam through desert dust, hyper-detailed textures, cinematic orange and teal grading, 16:9 composition, off-center focal point, documentary premium quality.
```
